# Daily Check QQ (native Kotlin)
Laporan Pemeriksaan Kualitas & Kuantitas SPBU COCO 31.107.02 Samanhudi.
- Form 1 Dipping & Manhole, Form 2 Density & Kualitas, Form 3 Uji Tera Nozzel + foto
- Logo Pertamina Retail (embed di res/drawable-nodpi) dan tanda tangan digambar pas di kolom (fit lebar x tinggi)
- TTD bulat = Pws / M Raden Johan S, TTD segitiga = Perliq / Ferliq Pontumika Yuditama
- Ka Shift: tanda tangan digambar dengan jari
- Output PDF A4 ke folder Download, bisa dibagikan (WhatsApp, dll)
Build: `gradle assembleDebug`
