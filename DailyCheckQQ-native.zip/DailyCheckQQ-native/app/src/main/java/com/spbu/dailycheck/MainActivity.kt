package com.spbu.dailycheck

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private val vm: ReportVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                App(vm, onSave = { export(false) }, onShare = { export(true) })
            }
        }
    }

    private fun export(share: Boolean) {
        val data = vm.toData()
        Toast.makeText(this, "Membuat PDF...", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { PdfReport(applicationContext, data).saveToDownloads() }
            }
            result.onSuccess { uri ->
                if (share) {
                    sharePdf(uri)
                } else {
                    Toast.makeText(
                        this@MainActivity, "Tersimpan di folder Download", Toast.LENGTH_LONG
                    ).show()
                    openPdf(uri)
                }
            }.onFailure {
                Toast.makeText(
                    this@MainActivity, "Gagal membuat PDF: " + it.message, Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun openPdf(uri: Uri) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            )
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Tidak ada aplikasi pembuka PDF. File ada di folder Download.", Toast.LENGTH_LONG).show()
        }
    }

    private fun sharePdf(uri: Uri) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Kirim laporan"))
    }
}
