package com.spbu.dailycheck

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint

sealed class Cell {
    class T(val s: String, val bold: Boolean = false) : Cell()
    class P(val b: Bitmap?) : Cell()
    class Prod(val name: String, val logo: Bitmap?) : Cell()
}

/**
 * Pembuat PDF A4 (595 x 842 pt) dengan Canvas.
 * Semua gambar (logo Pertamina Retail, tanda tangan, foto, logo produk)
 * digambar lewat fit(): diskalakan proporsional agar pas di lebar x tinggi kolomnya.
 */
class PdfReport(private val ctx: Context, private val d: ReportData) {

    private val navy = Color.rgb(0, 48, 135)
    private val PW = 595
    private val PH = 842
    private val M = 32f
    private val CW = PW - 2 * M
    private val bottomLimit = PH - M - 18f

    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private lateinit var cv: Canvas
    private var y = 0f
    private var pageNo = 0
    private var curForm = ""

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(110, 110, 110)
        style = Paint.Style.STROKE
        strokeWidth = 0.8f
    }
    private val fillNavy = Paint().apply {
        color = navy
        style = Paint.Style.FILL
    }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 9f
    }
    private val tpB = TextPaint(tp).apply { typeface = Typeface.DEFAULT_BOLD }
    private val tpW = TextPaint(tpB).apply { color = Color.WHITE }
    private val tpTitle = TextPaint(tpB).apply { textSize = 10f }
    private val tpNavy = TextPaint(tpB).apply { color = navy; textSize = 10f }
    private val tpSmall = TextPaint(tp).apply { textSize = 7.5f; color = Color.GRAY }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    // ---- gambar bawaan ----
    private fun res(id: Int): Bitmap? =
        BitmapFactory.decodeResource(ctx.resources, id, BitmapFactory.Options().apply { inScaled = false })

    private val logo: Bitmap? by lazy { res(R.drawable.logo_pertamina_retail) }
    private val ttdBulat: Bitmap? by lazy { res(R.drawable.ttd_bulat) }
    private val ttdSegitiga: Bitmap? by lazy { res(R.drawable.ttd_segitiga) }
    private val prodCache = HashMap<Int, Bitmap?>()
    private val photoCache = HashMap<Uri, Bitmap?>()

    private fun prodLogo(name: String): Bitmap? {
        val id = Products.logoRes(name) ?: return null
        return prodCache.getOrPut(id) { res(id) }
    }

    private fun img(u: Uri?): Bitmap? {
        if (u == null) return null
        return photoCache.getOrPut(u) { ImageUtil.decode(ctx, u, 1000) }
    }

    // ---- util gambar & teks ----
    /** Skala proporsional supaya muat di dalam kotak r (lebar x tinggi), lalu tengahkan. */
    private fun fit(b: Bitmap?, r: RectF) {
        if (b == null || b.width == 0 || b.height == 0) return
        val s = minOf(r.width() / b.width, r.height() / b.height)
        val dw = b.width * s
        val dh = b.height * s
        val l = r.left + (r.width() - dw) / 2f
        val t = r.top + (r.height() - dh) / 2f
        cv.drawBitmap(b, null, RectF(l, t, l + dw, t + dh), bmpPaint)
    }

    private fun layout(
        text: String,
        w: Float,
        p: TextPaint,
        align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL
    ): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, w.toInt().coerceAtLeast(1))
            .setAlignment(align)
            .setIncludePad(false)
            .build()

    private fun drawLayout(l: StaticLayout, x: Float, top: Float) {
        cv.save()
        cv.translate(x, top)
        l.draw(cv)
        cv.restore()
    }

    // ---- halaman ----
    private fun startForm(title: String) {
        if (page != null) finishPage()
        curForm = title
        beginPage(false)
    }

    private fun newPage() {
        finishPage()
        beginPage(true)
    }

    private fun beginPage(cont: Boolean) {
        pageNo++
        val p = doc.startPage(PdfDocument.PageInfo.Builder(PW, PH, pageNo).create())
        page = p
        cv = p.canvas
        y = M
        drawHeader(if (cont) "$curForm (lanjutan)" else curForm)
    }

    private fun finishPage() {
        val p = page ?: return
        cv.drawText("SPBU COCO 31.107.02 SAMANHUDI  -  Halaman $pageNo", M, PH - 18f, tpSmall)
        doc.finishPage(p)
        page = null
    }

    private fun drawHeader(form: String) {
        val h = 66f
        val logoW = 112f
        val infoW = 176f
        val x0 = M
        cv.drawRect(x0, y, x0 + logoW, y + h, line)
        cv.drawRect(x0 + logoW, y, x0 + CW - infoW, y + h, line)
        cv.drawRect(x0 + CW - infoW, y, x0 + CW, y + h, line)

        // Logo Pertamina Retail: pas di kolom kiri (lebar x tinggi)
        fit(logo, RectF(x0 + 5f, y + 5f, x0 + logoW - 5f, y + h - 5f))

        val mw = CW - logoW - infoW - 8f
        val tl = layout(
            "LAPORAN PEMERIKSAAN KUALITAS DAN KUANTITAS\nSPBU COCO\n31.107.02 SAMANHUDI",
            mw, tpTitle, Layout.Alignment.ALIGN_CENTER
        )
        drawLayout(tl, x0 + logoW + 4f, y + (h - tl.height) / 2f)

        val il = layout("No Dokumen: ${d.noDok}\nHari/Tanggal: ${d.tanggal}", infoW - 10f, tp)
        drawLayout(il, x0 + CW - infoW + 5f, y + (h - il.height) / 2f)
        y += h + 8f

        cv.drawRect(M, y, M + CW, y + 20f, fillNavy)
        val bl = layout(form, CW - 12f, tpW)
        drawLayout(bl, M + 6f, y + (20f - bl.height) / 2f)
        y += 28f
    }

    // ---- tabel ----
    private fun headerRow(titles: List<String>, ws: List<Float>) {
        val ls = titles.mapIndexed { i, t -> layout(t, ws[i] - 6f, tpW, Layout.Alignment.ALIGN_CENTER) }
        val h = (ls.maxOf { it.height } + 10f).coerceAtLeast(22f)
        var x = M
        for (i in titles.indices) {
            cv.drawRect(x, y, x + ws[i], y + h, fillNavy)
            cv.drawRect(x, y, x + ws[i], y + h, line)
            drawLayout(ls[i], x + 3f, y + (h - ls[i].height) / 2f)
            x += ws[i]
        }
        y += h
    }

    private fun rowHeight(r: List<Cell>, ws: List<Float>, picH: Float): Float {
        var h = 24f
        r.forEachIndexed { i, c ->
            val ch: Float = when (c) {
                is Cell.T -> layout(
                    c.s, ws[i] - 8f, if (c.bold) tpB else tp, Layout.Alignment.ALIGN_CENTER
                ).height + 10f
                is Cell.P -> picH
                is Cell.Prod -> 58f
            }
            if (ch > h) h = ch
        }
        return h
    }

    private fun drawRow(r: List<Cell>, ws: List<Float>, h: Float) {
        var x = M
        r.forEachIndexed { i, c ->
            val w = ws[i]
            cv.drawRect(x, y, x + w, y + h, line)
            when (c) {
                is Cell.T -> {
                    val l = layout(c.s, w - 8f, if (c.bold) tpB else tp, Layout.Alignment.ALIGN_CENTER)
                    drawLayout(l, x + 4f, y + (h - l.height) / 2f)
                }
                is Cell.P -> {
                    if (c.b == null) {
                        val l = layout("-", w - 8f, tp, Layout.Alignment.ALIGN_CENTER)
                        drawLayout(l, x + 4f, y + (h - l.height) / 2f)
                    } else {
                        // Foto / gambar: pas di kolom (lebar x tinggi)
                        fit(c.b, RectF(x + 3f, y + 3f, x + w - 3f, y + h - 3f))
                    }
                }
                is Cell.Prod -> {
                    val l = layout(c.name, w - 8f, tpB, Layout.Alignment.ALIGN_CENTER)
                    drawLayout(l, x + 4f, y + h - 5f - l.height)
                    fit(c.logo, RectF(x + 6f, y + 4f, x + w - 6f, y + h - l.height - 9f))
                }
            }
            x += w
        }
        y += h
    }

    private fun table(titles: List<String>?, fr: List<Float>, rows: List<List<Cell>>, picH: Float) {
        val ws = fr.map { it * CW }
        if (titles != null) {
            if (y + 70f > bottomLimit) newPage()
            headerRow(titles, ws)
        }
        for (r in rows) {
            val h = rowHeight(r, ws, picH)
            if (y + h > bottomLimit) {
                newPage()
                if (titles != null) headerRow(titles, ws)
            }
            drawRow(r, ws, h)
        }
    }

    // ---- blok tanda tangan ----
    private fun sigBlock() {
        val hHead = 32f
        val hSig = 84f
        val hName = 24f
        if (y + hHead + hSig + hName + 14f > bottomLimit) newPage()
        y += 14f
        val w = CW / 3f
        val heads = listOf("Dibuat", "Diketahui", "Mengetahui")
        val roles = listOf("Ka Shift", "Pws", "Perliq")
        val names = listOf(d.kaName, d.pwsName, d.perliqName)
        // Ka Shift = coretan di aplikasi, Pws = TTD bulat, Perliq = TTD segitiga
        val sigs = listOf(d.kaSig, ttdBulat, ttdSegitiga)
        for (i in 0..2) {
            val x = M + i * w
            cv.drawRect(x, y, x + w, y + hHead, line)
            val hl = layout("${heads[i]}\n${roles[i]}", w - 8f, tpB, Layout.Alignment.ALIGN_CENTER)
            drawLayout(hl, x + 4f, y + (hHead - hl.height) / 2f)

            val sy = y + hHead
            cv.drawRect(x, sy, x + w, sy + hSig, line)
            fit(sigs[i], RectF(x + 8f, sy + 6f, x + w - 8f, sy + hSig - 6f))

            val ny = sy + hSig
            cv.drawRect(x, ny, x + w, ny + hName, line)
            val nl = layout(names[i], w - 8f, tpB, Layout.Alignment.ALIGN_CENTER)
            drawLayout(nl, x + 4f, ny + (hName - nl.height) / 2f)
        }
        y += hHead + hSig + hName
    }

    // ---- isi laporan ----
    private fun build() {
        // FORM 1
        startForm("FORM 1 - DOKUMENTASI DIPPING & MANHOLE")
        table(
            listOf("NO Tangki", "PRODUK", "DOKUMENTASI DIPPING", "DOKUMENTASI MANHOLE", "HASIL PEMERIKSAAN"),
            listOf(0.08f, 0.18f, 0.22f, 0.22f, 0.30f),
            d.f1.map {
                listOf(
                    Cell.T(it.tank), Cell.Prod(it.produk, prodLogo(it.produk)),
                    Cell.P(img(it.dipping)), Cell.P(img(it.manhole)), Cell.T(it.hasil)
                )
            },
            110f
        )
        sigBlock()

        // FORM 2
        startForm("FORM 2 - DOKUMENTASI DENSITY & KUALITAS")
        table(
            listOf("NO Tangki", "PRODUK", "DOKUMENTASI DENSITY", "HASIL PEMERIKSAAN (Density Obs / Suhu °C / Density 15°C)", "KUALITAS"),
            listOf(0.08f, 0.18f, 0.22f, 0.36f, 0.16f),
            d.f2.map {
                listOf(
                    Cell.T(it.tank), Cell.Prod(it.produk, prodLogo(it.produk)),
                    Cell.P(img(it.density)),
                    Cell.T("Density Obs : ${it.obs}\nSuhu : ${it.suhu} °C\nDensity 15°C : ${it.d15}"),
                    Cell.T(it.kualitas, true)
                )
            },
            110f
        )
        sigBlock()

        // FORM 3
        startForm("FORM 3 - UJI TERA NOZZEL")
        table(
            listOf("PRODUK", "NO. DISPENSER", "NO. NOZZEL", "VOLUME BBM KELUAR", "HASIL UJI TERA"),
            listOf(0.22f, 0.14f, 0.14f, 0.22f, 0.28f),
            d.f3.map {
                listOf(
                    Cell.Prod(it.produk, prodLogo(it.produk)),
                    Cell.T(it.dispenser), Cell.T(it.nozzel), Cell.T(it.volume), Cell.T(it.hasil)
                )
            },
            60f
        )
        if (d.fotoTera.isNotEmpty()) {
            if (y + 60f > bottomLimit) newPage()
            y += 12f
            val tl = layout("Dokumentasi Foto Uji Tera", CW, tpNavy)
            drawLayout(tl, M, y)
            y += tl.height + 6f
            val rows = d.fotoTera.chunked(3).map { chunk ->
                val cells = ArrayList<Cell>()
                chunk.forEach { cells.add(Cell.P(img(it))) }
                while (cells.size < 3) cells.add(Cell.T(""))
                cells
            }
            table(null, listOf(1f / 3f, 1f / 3f, 1f / 3f), rows, 140f)
        }
        sigBlock()
        finishPage()
    }

    /** Buat PDF lalu simpan ke folder Download. Mengembalikan Uri file. */
    fun saveToDownloads(): Uri {
        build()
        val name = "Laporan_SPBU_31.107.02_${d.fileDate}.pdf"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Gagal membuat file di Download")
        resolver.openOutputStream(uri)?.use { doc.writeTo(it) }
            ?: throw IllegalStateException("Gagal menulis file")
        doc.close()
        return uri
    }
}
