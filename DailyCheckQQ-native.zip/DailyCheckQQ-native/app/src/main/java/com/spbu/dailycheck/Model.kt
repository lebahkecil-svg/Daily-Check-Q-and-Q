package com.spbu.dailycheck

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val DEFAULT_HASIL = "Tidak ditemukan air Pada Manhole dan Tangki Pendam"

object Products {
    val list = listOf(
        "Pertalite", "Pertamax", "Pertamax Green 95",
        "Pertamax Turbo", "Dexlite", "Pertamina Dex"
    )

    fun logoRes(name: String): Int? = when (name) {
        "Pertalite" -> R.drawable.logo_pertalite
        "Pertamax" -> R.drawable.logo_pertamax
        "Pertamax Green 95" -> R.drawable.logo_pertamax_green
        "Pertamax Turbo" -> R.drawable.logo_pertamax_turbo
        "Dexlite" -> R.drawable.logo_dexlite
        "Pertamina Dex" -> R.drawable.logo_dex
        else -> null
    }
}

class F1Row(tank: String = "") {
    var tank by mutableStateOf(tank)
    var produk by mutableStateOf(Products.list[0])
    var dipping by mutableStateOf<Uri?>(null)
    var manhole by mutableStateOf<Uri?>(null)
    var hasil by mutableStateOf(DEFAULT_HASIL)
}

class F2Row(tank: String = "") {
    var tank by mutableStateOf(tank)
    var produk by mutableStateOf(Products.list[0])
    var density by mutableStateOf<Uri?>(null)
    var obs by mutableStateOf("")
    var suhu by mutableStateOf("")
    var d15 by mutableStateOf("")
    var kualitas by mutableStateOf("On Spec")
}

class F3Row {
    var produk by mutableStateOf(Products.list[0])
    var dispenser by mutableStateOf("")
    var nozzel by mutableStateOf("")
    var volume by mutableStateOf("")
    var hasil by mutableStateOf("")
}

// ---- Data polos (snapshot) untuk dikirim ke pembuat PDF ----
data class F1Data(val tank: String, val produk: String, val dipping: Uri?, val manhole: Uri?, val hasil: String)
data class F2Data(val tank: String, val produk: String, val density: Uri?, val obs: String, val suhu: String, val d15: String, val kualitas: String)
data class F3Data(val produk: String, val dispenser: String, val nozzel: String, val volume: String, val hasil: String)

data class ReportData(
    val tanggal: String,
    val fileDate: String,
    val noDok: String,
    val f1: List<F1Data>,
    val f2: List<F2Data>,
    val f3: List<F3Data>,
    val fotoTera: List<Uri>,
    val kaName: String,
    val pwsName: String,
    val perliqName: String,
    val kaSig: Bitmap?
)

class ReportVM : ViewModel() {
    var tanggalMillis by mutableLongStateOf(System.currentTimeMillis())
    var noDokumen by mutableStateOf("")

    val f1 = mutableStateListOf(F1Row("1"))
    val f2 = mutableStateListOf(F2Row("1"))
    val f3 = mutableStateListOf(F3Row())
    val fotoTera = mutableStateListOf<Uri?>(null)

    var kaName by mutableStateOf("BUDI PRASETYO")
    var pwsName by mutableStateOf("M RADEN JOHAN S")
    var perliqName by mutableStateOf("FERLIQ PONTUMIKA YUDITAMA")
    var kaSig by mutableStateOf<Bitmap?>(null)

    fun tanggalText(): String =
        SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID")).format(Date(tanggalMillis))

    fun toData(): ReportData {
        val ymd = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(tanggalMillis))
        return ReportData(
            tanggal = tanggalText(),
            fileDate = ymd,
            noDok = if (noDokumen.isBlank()) "QQ/$ymd" else noDokumen,
            f1 = f1.map { F1Data(it.tank, it.produk, it.dipping, it.manhole, it.hasil) },
            f2 = f2.map { F2Data(it.tank, it.produk, it.density, it.obs, it.suhu, it.d15, it.kualitas) },
            f3 = f3.map { F3Data(it.produk, it.dispenser, it.nozzel, it.volume, it.hasil) },
            fotoTera = fotoTera.filterNotNull(),
            kaName = kaName,
            pwsName = pwsName,
            perliqName = perliqName,
            kaSig = kaSig
        )
    }
}
