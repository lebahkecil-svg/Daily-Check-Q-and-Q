@file:OptIn(ExperimentalMaterial3Api::class)

package com.spbu.dailycheck

import android.app.DatePickerDialog
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

private val Navy = Color(0xFF003087)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Navy, secondary = Color(0xFFE30613)),
        content = content
    )
}

@Composable
fun App(vm: ReportVM, onSave: () -> Unit, onShare: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Info", "Form 1", "Form 2", "Form 3", "TTD")
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Daily Check SPBU 31.107.02") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Navy,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = { BottomActions(onSave, onShare) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                tabs.forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
                }
            }
            when (tab) {
                0 -> InfoTab(vm)
                1 -> Form1Tab(vm)
                2 -> Form2Tab(vm)
                3 -> Form3Tab(vm)
                else -> TtdTab(vm)
            }
        }
    }
}

@Composable
fun BottomActions(onSave: () -> Unit, onShare: () -> Unit) {
    Surface(shadowElevation = 8.dp) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = onSave, modifier = Modifier.weight(1f)) { Text("Simpan PDF") }
            OutlinedButton(onClick = onShare, modifier = Modifier.weight(1f)) { Text("Bagikan") }
        }
    }
}

// ---------- komponen umum ----------

@Composable
fun FormScroll(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        content()
    }
}

@Composable
fun CardBox(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Navy)
            content()
        }
    }
}

@Composable
fun Field(
    label: String,
    value: String,
    kb: KeyboardType = KeyboardType.Text,
    modifier: Modifier = Modifier.fillMaxWidth(),
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = kb)
    )
}

@Composable
fun RowButtons(onAdd: () -> Unit, onRemove: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onAdd, modifier = Modifier.weight(1f)) { Text("Tambah Baris") }
        OutlinedButton(onClick = onRemove, modifier = Modifier.weight(1f)) { Text("Hapus Terakhir") }
    }
}

@Composable
fun ProductDropdown(value: String, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Produk: $value")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            Products.list.forEach { p ->
                DropdownMenuItem(text = { Text(p) }, onClick = { onSelect(p); open = false })
            }
        }
    }
}

@Composable
fun PhotoBox(label: String, uri: Uri?, onChange: (Uri?) -> Unit) {
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf(false) }
    val camUri = remember { mutableStateOf<Uri?>(null) }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) onChange(u)
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri.value
        if (ok && u != null) onChange(u)
    }
    val thumb by produceState<Bitmap?>(null, uri) {
        value = if (uri == null) null else withContext(Dispatchers.IO) { ImageUtil.decode(ctx, uri, 500) }
    }

    Box(
        Modifier.fillMaxWidth().height(130.dp)
            .clip(MaterialTheme.shapes.small)
            .border(1.dp, Color.Gray, MaterialTheme.shapes.small)
            .clickable { dlg = true },
        contentAlignment = Alignment.Center
    ) {
        val b = thumb
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = label,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(label + " (ketuk)", color = Color.Gray)
        }
    }

    if (dlg) {
        AlertDialog(
            onDismissRequest = { dlg = false },
            title = { Text(label) },
            text = {
                Column {
                    TextButton(onClick = {
                        dlg = false
                        val u = ImageUtil.newCameraUri(ctx)
                        camUri.value = u
                        camera.launch(u)
                    }) { Text("Ambil dengan Kamera") }
                    TextButton(onClick = {
                        dlg = false
                        gallery.launch("image/*")
                    }) { Text("Pilih dari Galeri") }
                    TextButton(onClick = {
                        dlg = false
                        onChange(null)
                    }) { Text("Hapus") }
                }
            },
            confirmButton = { TextButton(onClick = { dlg = false }) { Text("Tutup") } }
        )
    }
}

// ---------- tab ----------

@Composable
fun InfoTab(vm: ReportVM) {
    val ctx = LocalContext.current
    FormScroll {
        Image(
            painter = painterResource(R.drawable.logo_pertamina_retail),
            contentDescription = "Logo Pertamina Retail",
            modifier = Modifier.height(56.dp),
            contentScale = ContentScale.Fit
        )
        Text("SPBU COCO 31.107.02 SAMANHUDI", fontWeight = FontWeight.Bold)
        Text("Hari/Tanggal: " + vm.tanggalText())
        Button(onClick = {
            val c = Calendar.getInstance().apply { timeInMillis = vm.tanggalMillis }
            DatePickerDialog(
                ctx,
                { _, yy, mm, dd ->
                    val cc = Calendar.getInstance()
                    cc.set(yy, mm, dd)
                    vm.tanggalMillis = cc.timeInMillis
                },
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)
            ).show()
        }) { Text("Pilih tanggal") }
        Field("No Dokumen (kosongkan = otomatis)", vm.noDokumen) { vm.noDokumen = it }
    }
}

@Composable
fun Form1Tab(vm: ReportVM) {
    FormScroll {
        Text("Form 1 - Dokumentasi Dipping & Manhole", fontWeight = FontWeight.Bold)
        vm.f1.forEachIndexed { i, r ->
            CardBox("Baris ${i + 1}") {
                Field("No Tangki", r.tank) { r.tank = it }
                ProductDropdown(r.produk) { r.produk = it }
                PhotoBox("Foto dipping", r.dipping) { r.dipping = it }
                PhotoBox("Foto manhole", r.manhole) { r.manhole = it }
                Field("Hasil pemeriksaan", r.hasil) { r.hasil = it }
            }
        }
        RowButtons(
            onAdd = { vm.f1.add(F1Row((vm.f1.size + 1).toString())) },
            onRemove = { if (vm.f1.size > 1) vm.f1.removeAt(vm.f1.lastIndex) }
        )
    }
}

@Composable
fun Form2Tab(vm: ReportVM) {
    FormScroll {
        Text("Form 2 - Dokumentasi Density & Kualitas", fontWeight = FontWeight.Bold)
        vm.f2.forEachIndexed { i, r ->
            CardBox("Baris ${i + 1}") {
                Field("No Tangki", r.tank) { r.tank = it }
                ProductDropdown(r.produk) { r.produk = it }
                PhotoBox("Foto density", r.density) { r.density = it }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Field("Density Obs", r.obs, KeyboardType.Decimal, Modifier.weight(1f)) { r.obs = it }
                    Field("Suhu °C", r.suhu, KeyboardType.Decimal, Modifier.weight(1f)) { r.suhu = it }
                    Field("Density 15°C", r.d15, KeyboardType.Decimal, Modifier.weight(1f)) { r.d15 = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("On Spec", "Off Spec").forEach { q ->
                        FilterChip(
                            selected = r.kualitas == q,
                            onClick = { r.kualitas = q },
                            label = { Text(q) }
                        )
                    }
                }
            }
        }
        RowButtons(
            onAdd = { vm.f2.add(F2Row((vm.f2.size + 1).toString())) },
            onRemove = { if (vm.f2.size > 1) vm.f2.removeAt(vm.f2.lastIndex) }
        )
    }
}

@Composable
fun Form3Tab(vm: ReportVM) {
    FormScroll {
        Text("Form 3 - Uji Tera Nozzel", fontWeight = FontWeight.Bold)
        vm.f3.forEachIndexed { i, r ->
            CardBox("Baris ${i + 1}") {
                ProductDropdown(r.produk) { r.produk = it }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Field("No. Dispenser", r.dispenser, KeyboardType.Text, Modifier.weight(1f)) { r.dispenser = it }
                    Field("No. Nozzel", r.nozzel, KeyboardType.Text, Modifier.weight(1f)) { r.nozzel = it }
                }
                Field("Volume BBM keluar", r.volume) { r.volume = it }
                Field("Hasil uji tera", r.hasil) { r.hasil = it }
            }
        }
        RowButtons(
            onAdd = { vm.f3.add(F3Row()) },
            onRemove = { if (vm.f3.size > 1) vm.f3.removeAt(vm.f3.lastIndex) }
        )
        CardBox("Dokumentasi Foto Uji Tera") {
            vm.fotoTera.forEachIndexed { i, u ->
                PhotoBox("Foto ${i + 1}", u) { vm.fotoTera[i] = it }
            }
            RowButtons(
                onAdd = { vm.fotoTera.add(null) },
                onRemove = { if (vm.fotoTera.isNotEmpty()) vm.fotoTera.removeAt(vm.fotoTera.lastIndex) }
            )
        }
    }
}

@Composable
fun TtdTab(vm: ReportVM) {
    val ctx = LocalContext.current
    FormScroll {
        Text(
            "Logo & tanda tangan otomatis dipasang pas di kolomnya pada setiap form di PDF.",
            color = Color.Gray
        )
        CardBox("Dibuat - Ka Shift") {
            Field("Nama", vm.kaName) { vm.kaName = it }
            val sig = vm.kaSig
            if (sig != null) {
                Image(
                    bitmap = sig.asImageBitmap(),
                    contentDescription = "TTD Ka Shift",
                    modifier = Modifier.height(100.dp),
                    contentScale = ContentScale.Fit
                )
                OutlinedButton(onClick = { vm.kaSig = null }) { Text("Hapus TTD") }
            } else {
                val pad = remember { SigPadView(ctx) }
                Text("Gambar tanda tangan dengan jari di kotak abu-abu:", color = Color.Gray)
                AndroidView(factory = { pad }, modifier = Modifier.fillMaxWidth().height(160.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pad.clear() }) { Text("Hapus coretan") }
                    Button(onClick = { vm.kaSig = pad.toBitmap() }) { Text("Simpan TTD") }
                }
            }
        }
        CardBox("Diketahui - Pws (TTD bulat)") {
            Field("Nama", vm.pwsName) { vm.pwsName = it }
            Image(
                painter = painterResource(R.drawable.ttd_bulat),
                contentDescription = "TTD bulat Pws",
                modifier = Modifier.height(110.dp),
                contentScale = ContentScale.Fit
            )
        }
        CardBox("Mengetahui - Perliq (TTD segitiga)") {
            Field("Nama", vm.perliqName) { vm.perliqName = it }
            Image(
                painter = painterResource(R.drawable.ttd_segitiga),
                contentDescription = "TTD segitiga Perliq",
                modifier = Modifier.height(80.dp),
                contentScale = ContentScale.Fit
            )
        }
    }
}
