package com.spbu.dailycheck

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** Kotak abu-abu untuk menggambar tanda tangan dengan jari. */
class SigPadView(ctx: Context) : View(ctx) {
    private val path = Path()
    private var hasInk = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    init {
        setBackgroundColor(Color.rgb(238, 238, 238))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawPath(path, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                path.moveTo(e.x, e.y)
                path.lineTo(e.x + 0.1f, e.y + 0.1f)
                hasInk = true
            }
            MotionEvent.ACTION_MOVE -> path.lineTo(e.x, e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                parent?.requestDisallowInterceptTouchEvent(false)
            else -> return false
        }
        invalidate()
        return true
    }

    fun clear() {
        path.reset()
        hasInk = false
        invalidate()
    }

    /** Bitmap transparan, sudah dipangkas ke batas goresan. */
    fun toBitmap(): Bitmap? {
        if (!hasInk) return null
        val rf = RectF()
        path.computeBounds(rf, true)
        rf.inset(-8f, -8f)
        val w = rf.width().toInt().coerceAtLeast(1)
        val h = rf.height().toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.translate(-rf.left, -rf.top)
        c.drawPath(path, paint)
        return bmp
    }
}
